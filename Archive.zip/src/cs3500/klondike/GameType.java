package cs3500.klondike;

/**
 * represents all playable variants of klondike as enumerations.
 */
public enum GameType {
  BASIC, LIMITED, WHITEHEAD
}
