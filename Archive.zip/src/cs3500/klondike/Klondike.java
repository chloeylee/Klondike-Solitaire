package cs3500.klondike;

import java.io.IOException;
import java.io.InputStreamReader;

import cs3500.klondike.controller.KlondikeController;
import cs3500.klondike.controller.KlondikeTextualController;
import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.KlondikeModel;

/**
 * represents all playable variants of klondike.
 */
public class Klondike {

  /**
   * entry point for the klondike program.
   * @param args the inputted arguments
   * @throws IOException if the appendable fails
   */
  public static void main(String[] args) {
    KlondikeModel model = new BasicKlondike();
    Readable r = new InputStreamReader(System.in);
    Appendable ap = System.out;
    KlondikeController controller = new KlondikeTextualController(r, ap);

    controller.playGame(model, model.getDeck(), false, 7, 3);
  }
}
